# TODO: Add comment
# 
# Author: frohlich
###############################################################################


.onLoad <- function(lib, pkgname){
	library.dynam(pkgname, pkgname, lib)
}
